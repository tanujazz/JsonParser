package mygroup.myproject;

public class JsonParser {

}
