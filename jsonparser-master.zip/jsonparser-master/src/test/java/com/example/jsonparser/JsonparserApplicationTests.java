package com.example.jsonparser;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.File;
import java.io.IOException;

import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.jsonparser.beans.Bid;
import com.example.jsonparser.beans.BidResponse;
import com.example.jsonparser.business.JsonBusinessLogic;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@SpringBootTest
class JsonparserApplicationTests {
	@Autowired
	JsonBusinessLogic testLogic ;
	@Test
	void contextLoads() {
	}
	
	ObjectMapper objectMapper = new ObjectMapper();
    BidResponse bidResponse = null;
    Bid highestBid = null;
	/*
	 * @Before public void setUp() { Employee alex = new Employee("alex");
	 * 
	 * Mockito.when(employeeRepository.findByName(alex.getName()))
	 * .thenReturn(alex); }
	 */
	
	@Test
	public void validID() throws JsonParseException, JsonMappingException, IOException {
	    String id = "r48KQjc0LjbbJCqkWt8BeACCMTc0LgAAAABfH.XG-0";
	     objectMapper = new ObjectMapper();
	     bidResponse = objectMapper.readValue(new File("src/main/resources/bid-response.json"), BidResponse.class);
	     highestBid = testLogic.getHighestBid(bidResponse);
	 
	    assertEquals(id, highestBid.getId());
	 }
	
	@Test
	public void invalidID() throws JsonParseException, JsonMappingException, IOException {
	    String id = "1";
	    objectMapper = new ObjectMapper();
	     bidResponse = objectMapper.readValue(new File("src/main/resources/bid-response.json"), BidResponse.class);
	     highestBid = testLogic.getHighestBid(bidResponse);
	 
	    assertNotEquals(id, highestBid.getId());
	 }

	@Test
	public void validPrice() throws JsonParseException, JsonMappingException, IOException {
	    double price = 5.01089295;
	    objectMapper = new ObjectMapper();
	     bidResponse = objectMapper.readValue(new File("src/main/resources/bid-response.json"), BidResponse.class);
	     highestBid = testLogic.getHighestBid(bidResponse);
	 
	    assertEquals(price, highestBid.getPrice());
	 }
	
	@Test
	public void inValidPrice() throws JsonParseException, JsonMappingException, IOException {
	    double price = 5.0;
	    objectMapper = new ObjectMapper();
	     bidResponse = objectMapper.readValue(new File("src/main/resources/bid-response.json"), BidResponse.class);
	     highestBid = testLogic.getHighestBid(bidResponse);
	 
	    assertNotEquals(price, highestBid.getPrice());
	 }
	
	@Test
	public void validAdm() throws JsonParseException, JsonMappingException, IOException {
	    String adm = "<script type='text/javascript'>var adContent = '';\n" + 
	    		"adContent += '<!-- AdPlacement : y402781 --><!-- Oath SSP BannerAd DspId:5357, SeatId:951609, DspCrId:950933 --><!-- Ad Feedback Markup v1 -->' + '\\n';\n" + 
	    		"adContent += '                  <scr' + 'ipt id=\"yax_meta\" type=\"text/x-yax-meta\">' + '\\n';\n" + 
	    		"adContent += '                    {' + '\\n';\n" + 
	    		"adContent += '                      \"fdb_url\": \"https://beap-bc.yahoo.com/af/us?bv=1.0.0&bs=(15jccf9ca(gid$r48KQjc0LjbbJCqkWt8BeACCMTc0LgAAAABfH.XG-0,st$1548869882113000,li$9205,cr$950933,dmn$choosenissan.com,srv$4,exp$1548874682113000,ct$26,v$1.0,adv$9205,pbid$52469,seid$179355051))&al=(type${type},cmnt${cmnt},subo${subo})&r=44535\",' + '\\n';\n" + 
	    		"adContent += '                      \"fdb_on\": 1,' + '\\n';\n" + 
	    		"adContent += '                      \"fdb_exp\": 1548874682113,' + '\\n';\n" + 
	    		"adContent += '                      \"fdb_intl\": \"en-US\",' + '\\n';\n" + 
	    		"adContent += '                      \"err\": \"\"' + '\\n';\n" + 
	    		"adContent += '                    }' + '\\n';\n" + 
	    		"adContent += '                  </scr' + 'ipt>' + '\\n';\n" + 
	    		"adContent += '                  <scr' + 'ipt type=\"text/javascript\">' + '\\n';\n" + 
	    		"adContent += '                    (function() {' + '\\n';\n" + 
	    		"adContent += '                      var w = window,' + '\\n';\n" + 
	    		"adContent += '                        sf = (w && w.$sf && w.$sf.ext),' + '\\n';\n" + 
	    		"adContent += '                        di = document.getElementById(\"yax_meta\");' + '\\n';\n" + 
	    		"adContent += '' + '\\n';\n" + 
	    		"adContent += '                      if (sf && typeof sf.msg == \"function\" && di) {' + '\\n';\n" + 
	    		"adContent += '                        sf.msg({cmd:\"fdb\", data: di});' + '\\n';\n" + 
	    		"adContent += '                      }' + '\\n';\n" + 
	    		"adContent += '                    })();' + '\\n';\n" + 
	    		"adContent += '                  </scr' + 'ipt><i' + 'mg src=\"https://us-east-1.onemobile.yahoo.com/admax/adEvent.do?tidi=770771327&amp;sitepid=217491&amp;posi=770108&amp;grp=%3F%3F%3F&amp;nl=1548869882322&amp;rts=1548869882113&amp;pix=1&amp;et=1&amp;a=r48KQjc0LjbbJCqkWt8BeACCMTc0LgAAAABfH.XG-0&amp;m=aXAtMTAtMjItOC0xMzI.&amp;p=MC4wMDUwMTA4OTI5NQ&amp;b=OTIwNTs5NTE2MDk7Y2hvb3Nlbmlzc2FuLmNvbTs7Ow..&amp;xdi=Pz8_fD8_P3w_Pz98MA..&amp;xoi=MHxVU0E.&amp;hb=true&amp;type=5&amp;brxdPublisherId=20459933223&amp;brxdSiteId=4902551&amp;brxdSectionId=179355051&amp;dety=2\" style=\"display:none;width:1px;height:1px;border:0;\" width=\"1\" height=\"1\" alt=\"\"/><scr' + 'ipt type=\"text/javascript\" src=\"https://ads.yahoo.com/get-user-id?ver=2&n=23351&ts=1548869882113&sig=Hyht3Fb27523Grw0\"></scr' + 'ipt><scr' + 'ipt type=\"text/javascript\" src=\"https://pr.ybp.yahoo.com/ab/secure/true/imp/8D3qCG6CwGKZlPAJ4F9G12NuBZbZHP4tsfa1D1dm3gn2_3InU7q94TUJJA_4XIfYJeIG1AMD8WwV5i6e7T9ahDYlOvDWM1AcBz_WfsJJ70Y0BPiKeFOkfiwtmFgX-uB6L63om57cB-2hE2KMcNLflW76YY92mzVC9KmA2RUpVwrVVza2EPdpK_buLPMZXPUnalHD3WKmhWh_l1GSwhB7WgO-GJ91r-KjbwZ2PuZ-PayvFxqhHVKGel-0-oWm3F6zdNsSHyl-MgVeTj9lS4Gm0VTsXB7j-MUNo22yEa0xGxXS24g0hZER2HbVOapzlbk6edciQPraggSvko2wq5IASOqzTAk33EOd95DDmAWjPDkHUKQIA0MuBKlaDNGLo5BDdVm6Xv6eDsGRWeLn4u5NGxv_9Qkl4IDp3zyS2Jt5_PVSJX3gDpfgbom5QpERpvpI-vK-GkdOARrpFpWm2nvbUt4W8_rwgh-FtKM-AVEfI8n_pF72XjSrwltH9QK22hrZR1vjDFXIx2CZKlZqIjcdxic6Gi2SY4J8Ohzx7Xv4g2jJtWNqY5z5j4AJ2AhGCi6U3xy-g6HbsWDmnEZG8Vrw4k7jFZTBKR3tw5wrOTOjnyH3RBLImeHc3I5dbT-ztyA4-Tt7oK-ArAwVegvn5md7wrn-ydUp_rpJ6CFWa_uhWtiqjAtNPqwtOZAWVlOwIQF4Rw35kPT5cXjl_TrXKsoPDBjV0050GOZosdB57hKInE1z0n2SqtBjJBDDG7qV8IBTRIza1vE1EY8dA-vKLh9o7moJKGVqxJBNUdiAx7CuSEqpP6o5qQwPXq0sZasG1vlqfC3BF3UIWKmgXNbOxJinN5Fp1eSryrXWy4AV2A56KxeA2_usAba7JSFOqK-KHZeuG0418y_VlrVvPwCwbKaYFBiWslTLxRq4EuaUFG4a_rfaiFbT22HnxlAa4UoffLbr1JV7CACkw9yj4d058ohIC2wP2tH9qD4o1A8__nKBIDSV6gEaBpiEqCYx9TmPF9jhUuWZslRc6cRZN9Pguko8ZMyr1ZhwitaFqRmxcUtuV4tNg3nOXzx16Gvt5CjTdELHejqhtbLGK3dkGjaHd6ZHJZ7u3oGcSH7IV9sinrAIk4t3htzLwIeLuwD1xu7UDlq9jAuBXKoF4yg4ZWcYtLQsol274hNCUss4JSNLbuPg3rvF-u4DiwxzizJSSpJ3VHQPGSZXH27c-NV7iBwJrKzlteyOc6Aac-HrQbZyfya2W2txGfmphUIVlHP6XVTtq0PbLMzdZ2dxFfh7rzQQ-Nz_GDNKi1FiuVDI2GX4-psLI8_HQH91uYxrXvbMCyE4kSg6I-TZkLq7JtvflryVgkzrYl5BwPXz7W5Hsy7LYrdQKuW-6WGBr5otjY3PrYT753L_6PVkxBIYyjjUQsUJ6fL_30Uvr1Jn2ZZ4GU0qq7lACPI5EqZslJ1ygyhoS8LW1elM9x0pVUn12Zdy5UMGg9t6gWWHouOjjaPG_5HNCj1H499D6NB_1euGnVtsMf8lXsXnaHAacSUGsJGMv0jKKeHRF-JP2ZT0DKW6zX8tg-vf87_jUaUcq0UccBop-cetDNke/wp/5.01089295/pclick/https%3A%2F%2Fus-east-1.onemobile.yahoo.com%2Fadmax%2FadClick.do%3Fdcn%3Dbrxd4451051%26n%3DOath%2BAd%26id%3Da8d83a4f34ef441083508209c09806d9%26tid%3D2c9d288b0165651e4ea11f5ae0a20036%26nid%3D8a808aee2edf264a012f0d6ee4e87844%26pos%3Dy402781%26grp%3D%253F%253F%253F%26nl%3D1548869882322%26rts%3D1548869882113%26a%3Dr48KQjc0LjbbJCqkWt8BeACCMTc0LgAAAABfH.XG-0%26rdm%3D1%26rd%3D\"></scr' + 'ipt><!-- Ads by Oath Ad Platforms SSP - Optimized by NEXAGE - Wednesday, January 30, 2019 12:38:02 PM EST -->' + '\\n';\n" + 
	    		"document.write(adContent);</script>";
	    objectMapper = new ObjectMapper();
	     bidResponse = objectMapper.readValue(new File("src/main/resources/bid-response.json"), BidResponse.class);
	     highestBid = testLogic.getHighestBid(bidResponse);
	 
	    assertEquals(adm, highestBid.getAdm());
	 }
	
	@Test
	public void inValidAdm() throws JsonParseException, JsonMappingException, IOException {
		String adm = "xyz";
		objectMapper = new ObjectMapper();
	     bidResponse = objectMapper.readValue(new File("src/main/resources/bid-response.json"), BidResponse.class);
	     highestBid = testLogic.getHighestBid(bidResponse);
	 
	    assertNotEquals(adm, highestBid.getAdm());
	 }
	
	@Test
	public void isValidString() throws JsonParseException, JsonMappingException, IOException {
		
		objectMapper = new ObjectMapper();
	     bidResponse = objectMapper.readValue(new File("src/main/resources/bid-response.json"), BidResponse.class);
	     highestBid = testLogic.getHighestBid(bidResponse);
	    assertTrue(highestBid.getId() instanceof java.lang.String);
	}
}
