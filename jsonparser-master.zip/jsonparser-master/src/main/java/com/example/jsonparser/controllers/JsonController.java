package com.example.jsonparser.controllers;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Description;
import org.springframework.context.support.ResourceBundleMessageSource;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;
import org.thymeleaf.spring5.SpringTemplateEngine;
import org.thymeleaf.spring5.view.ThymeleafViewResolver;
import org.thymeleaf.templateresolver.ServletContextTemplateResolver;

import com.example.jsonparser.beans.Bid;
import com.example.jsonparser.beans.BidResponse;
import com.example.jsonparser.business.JsonBusinessLogic;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@RestController
public class JsonController {

	private Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	JsonBusinessLogic logic ;
	Bid highestBid = null;
	
	@GetMapping("/welcome")
	public String welcome() {
		return "Hello Welcome to Json Parser project.";

	}
	
	

	@GetMapping("/readJson")
	public String readJson() {

		ObjectMapper objectMapper = new ObjectMapper();
		BidResponse br = null ;
		try {
			 br = objectMapper.readValue(new File("src/main/resources/bid-response.json"), BidResponse.class);

		} catch (JsonParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (JsonMappingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		highestBid = logic.getHighestBid(br);

		return "Highest Bid = " + highestBid.getId()+ "\n " + "Highest Bid Price = " +highestBid.getPrice() + "\n"+ highestBid.getAdm().replaceAll("\n", "\r").replaceAll("\\\"", "\"");

	}
	
	// Mapping adm to HTML
	
	@GetMapping(value="/maxBid")
	    public ModelAndView homePage() {
		 ObjectMapper objectMapper = new ObjectMapper();
			BidResponse br = null ;
			try {
				 br = objectMapper.readValue(new File("src/main/resources/bid-response.json"), BidResponse.class);

			} catch (JsonParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (JsonMappingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			highestBid = logic.getHighestBid(br);
			ModelAndView mav = new ModelAndView();

	        mav.addObject("message", highestBid.getAdm());
	        mav.setViewName("show");

	        return mav;
	    }
	
	
	

}
