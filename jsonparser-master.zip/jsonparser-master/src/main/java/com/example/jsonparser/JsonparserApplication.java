package com.example.jsonparser;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JsonparserApplication {

	public static void main(String[] args) {
		SpringApplication.run(JsonparserApplication.class, args);
	}

}
